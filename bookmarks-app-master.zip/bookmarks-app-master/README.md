# Bookmarks React Client
_This project is a demonstration for Thinkful's React course_

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).
